package com.gpnv.helpcenter.firststart;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.gpnv.helpcenter.R;

public class MedicationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medications);
    }
}
