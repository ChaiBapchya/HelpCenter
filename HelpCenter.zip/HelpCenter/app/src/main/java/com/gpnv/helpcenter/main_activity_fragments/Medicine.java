package com.gpnv.helpcenter.main_activity_fragments;

public class Medicine {
    public String name;
    public String time;
    public String stock;

    Medicine(String name, String time,String stock) {
        this.name = name;
        this.time = time;
        this.stock=stock;
    }
}
